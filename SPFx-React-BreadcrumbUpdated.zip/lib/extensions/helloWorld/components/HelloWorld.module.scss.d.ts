declare const styles: {
    helloWorld: string;
};
export default styles;
