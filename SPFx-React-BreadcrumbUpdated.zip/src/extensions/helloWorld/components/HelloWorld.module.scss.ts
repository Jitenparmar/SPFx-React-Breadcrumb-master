/* tslint:disable */
require('./HelloWorld.module.css');
const styles = {
  helloWorld: 'helloWorld_32ff103e',
};

export default styles;
/* tslint:enable */