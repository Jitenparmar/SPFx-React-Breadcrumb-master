define([], function () {
    return {
        'SiteBreadcrumbLabel': 'Website breadcrumb',
        'ListViewGroupEmptyLabel': 'Empty',
        'WebPartTitlePlaceholder': 'Web part title',
        'WebPartTitleLabel': 'Add a title'
    };
});

//# sourceMappingURL=en-us.js.map
