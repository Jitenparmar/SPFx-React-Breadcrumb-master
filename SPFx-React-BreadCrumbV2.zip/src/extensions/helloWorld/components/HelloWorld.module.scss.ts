/* tslint:disable */
require('./HelloWorld.module.css');
const styles = {
  helloWorld: 'helloWorld_247e0555',
  breadcrumb: 'breadcrumb_247e0555',
  breadcrumbLinks: 'breadcrumbLinks_247e0555',
};

export default styles;
/* tslint:enable */