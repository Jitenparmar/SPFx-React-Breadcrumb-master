define([], function() {
  return {
    "Title": "HelloWorldApplicationCustomizer"
  }
});