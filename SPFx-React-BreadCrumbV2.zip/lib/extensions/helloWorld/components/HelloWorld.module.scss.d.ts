declare const styles: {
    helloWorld: string;
    breadcrumb: string;
    breadcrumbLinks: string;
};
export default styles;
