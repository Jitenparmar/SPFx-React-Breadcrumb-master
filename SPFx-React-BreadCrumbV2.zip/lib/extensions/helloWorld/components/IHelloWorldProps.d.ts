import ApplicationCustomizerContext from '@microsoft/sp-application-base/lib/extensibility/ApplicationCustomizerContext';
export interface IHelloWorldProps {
    context: ApplicationCustomizerContext;
}
